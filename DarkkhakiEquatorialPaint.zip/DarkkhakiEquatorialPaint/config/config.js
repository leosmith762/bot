module.exports = {
  settings: {
    prefix: '/',
    botName: 'Hr.BotHelper',
    ownerName: 'XGAMER91',
    ownerId: '64505224472da861d3d5e317',
    botId: 'da383dc30e44c510bba92afbdc490aceec9cb0680db292885769456f2268e23c',
    developers: ['leo_axo'],
    moderators: ['64505224472da861d3d5e317'],
    roomName: 'grabroom',
    coordinates: {
      x: 14.5,
      y: 9,
      z: 5.5,
      facing: 'FrontRight'
    },
    reactionName: 'wave'
  },
  authentication: {
    room: '64cc3b82271781694b3eca33',
    token: 'da383dc30e44c510bba92afbdc490aceec9cb0680db292885769456f2268e23c'
  }
}
